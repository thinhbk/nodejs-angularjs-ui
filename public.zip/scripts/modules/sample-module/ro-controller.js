define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('ROCtrl', ['$scope', '$log', 'PredixAssetService', '$state', '$http', '$interval', '$rootScope', '$stateParams', 'PredixTimeSeriesService', 'PostgresService',
        function ($scope, $log, PredixAssetService, $state, $http, $interval, $rootScope, $stateParams, PredixTimeSeriesService, PostgresService) {
            var self = this;
            var REFRESH_DATA_INTERVAL = 3000;
            var chartColors = ['#9d722a', '#059748', '#df5c24', '#3e87e8', '#88bde6'];

            // Init function
            (function () {
                var chartOptions = {
                    chart: {
                        animation: false,
                        type: 'pie',
                        spacingBottom: 35,
                        renderTo: "pieChartContainer",
                        style: {
                            color: 'silver'
                        }
                    },
                    title: {
                        text: '',
                        style: {
                            fontSize: '2em',
                            color: 'black'
                        }
                    },
                    exporting: { enabled: false },
                    credits: { enabled: false },
                    rangeSelector: { enabled: false },
                    tooltip: {
                        headerFormat: '<b>{point.x}</b><br/>',
                        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                                style: {
                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                }
                            }
                        }
                    },
                    series: [{
                        name: 'Brands',
                        colorByPoint: true,
                        data: [{
                            name: 'Microsoft Internet Explorer',
                            y: 56.33
                        }, {
                            name: 'Chrome',
                            y: 24.03,
                            sliced: true,
                            selected: true
                        }, {
                            name: 'Firefox',
                            y: 10.38
                        }, {
                            name: 'Safari',
                            y: 4.77
                        }, {
                            name: 'Opera',
                            y: 0.91
                        }, {
                            name: 'Proprietary or Undetectable',
                            y: 0.2
                        }]
                    }]
                };
                new Highcharts.Chart(chartOptions);

                var seriesOptions = [];
                PostgresService.getDataAvailability().then(function (data) {
                    data[0].tags.forEach(function (element) {
                        seriesOptions.push({
                            name: element.name,
                            data: element.results[0].datapoints
                        });
                    }, this);

                    new Highcharts.Chart({
                        chart: {
                            animation: false,
                            spacingBottom: 35,
                            renderTo: "timeSeriesChartContainer",
                            plotBackgroundColor: 'gray',
                            style: {
                                color: 'silver'
                            }
                        },
                        title: {
                            text: 'ATG Data Quality for RO',
                            style: {
                                fontSize: '2em',
                                color: 'black'
                            }
                        },
                        rangeSelector: {
                            selected: 4
                        },
                        xAxis: {
                            type: 'datetime',
                            dateTimeLabelFormats: { // don't display the dummy year
                                month: '%e. %b',
                                year: '%b'
                            },
                            title: {
                                text: 'Date'
                            }
                        },
                        yAxis: {
                            plotLines: [{
                                value: 0,
                                width: 2,
                                color: 'silver'
                            }]
                        },

                        plotOptions: {
                            series: {
                                compare: 'percent',
                                showInNavigator: true
                            }
                        },

                        tooltip: {
                            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.change}%)<br/>',
                            valueDecimals: 2,
                            split: true
                        },

                        series: seriesOptions
                    });
                });
                $scope.dataAvailability = [{ "product": "Petrol", "availability": "20" }, { "product": "Diesel", "availability": "30" }];
                $scope.fuelReconcilation = [{ "netfuelloss": "25", "losspersale": "20" }];
                $scope.wetStockReconcilation = [{ "phase": "25", "startdate": "18/05/2017", "billedvolume": "25", "decantationloss": "20", "decantedvolume": "25", "atglevel": "20", "tanksalevolume": "25", "salesloss": "20", "pumpsalevolume": "20" }];
                $scope.assetData = [{ "asset": "Tank", "assetno": "20" }, { "asset": "Dispenser", "assetno": "30" }, { "asset": "Nozzle", "assetno": "25" }];
                $scope.assetOptions = [{ "key": "Petrol", "val": "Petrol" }, { "key": "Diesel", "val": "Diesel" }];
            }());

            $scope.$on('$destroy', function iVeBeenDismissed() {
                // say goodbye to your controller here
                // $interval.cancel($scope.refreshPromiseTimer);
            });
            $scope.fromDateSubmit = function(){
                console.log("OK");
            };
        }]);
});
