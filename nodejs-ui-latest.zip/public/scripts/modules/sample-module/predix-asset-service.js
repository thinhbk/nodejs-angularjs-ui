define(['angular', './sample-module'], function(angular, module) {
    'use strict';

    /**
     * PredixAssetService is a sample service that integrates with Predix Asset Server API
     */
    module.factory('PredixAssetService', ['$q', '$http', '$rootScope', function($q, $http, $rootScope) {
        /**
         * Predix Asset server base url
         */
        var baseUrl = '/predix-api/predix-asset/';

        var getChildrentAssetsOfROById = function(model, roCode, level) {
            var deferred = $q.defer();

            var assetDetailsUrl = baseUrl + model + '?filter=ROCODE=' +roCode + '<parent[t' + level + ']';

            $http.get(assetDetailsUrl)
            .then(function (res) {
                deferred.resolve(res.data);
            },
            function () {
                deferred.reject('Error fetching reasons');
            });

            return deferred.promise;
        };


        return {
            getChildrentAssetsOfROById: getChildrentAssetsOfROById
        };
    }]);
});
