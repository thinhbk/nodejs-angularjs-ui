define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';

    // Controller definition
    controllers.controller('ROCtrl', ['$scope', '$log', 'PredixAssetService', '$state', '$http', '$interval', '$rootScope', '$stateParams', 'PredixTimeSeriesService', 'PostgresService',
        function ($scope, $log, PredixAssetService, $state, $http, $interval, $rootScope, $stateParams, PredixTimeSeriesService, PostgresService) {
            var self = this;
            var REFRESH_DATA_INTERVAL = 3000;
            var chartColors = ['#9d722a', '#059748', '#df5c24', '#3e87e8', '#88bde6'];

            $scope.filterData = function () {
                PostgresService.getDataForROById('rmdat1', $scope.fromDate, $scope.toDate).then(function (data) {
                    $scope.dataAvailability = data.map(function (item) {
                        return {
                            product: item[0],
                            availability: item[1]
                        };
                    });
                });

                PostgresService.getDataForROById('rmdmmp1', $scope.fromDate, $scope.toDate).then(function (data) {
                    var seriesOption = [{
                        name: 'Brands',
                        colorByPoint: true
                    }];
                    var pieChartData = [];
                    data[0].forEach(function (item) {
                        pieChartData.push({ y: item, name: item });
                    });
                    seriesOption[0].data = pieChartData;
                    console.log(seriesOption);
                    renderPieChart(seriesOption);
                });

                PostgresService.getDataForROById('rmda2lg', $scope.fromDate, $scope.toDate).then(function (data) {
                    var seriesOptions = [];
                    var currentTankSeries = { name: '', data: [] };
                    let currentTankNo = null;
                    data.forEach(function (element) {
                        if (currentTankNo) {
                            if (currentTankNo == element[0]) {
                                currentTankSeries.data.push([element[1], element[2]]);
                            } else {
                                seriesOptions.push(currentTankSeries);
                                currentTankSeries = { name: element[0], data: [] };
                                currentTankNo = element[0];
                                currentTankSeries.data.push([element[1], element[2]]);
                            }
                        } else {
                            currentTankNo = element[0];
                            currentTankSeries.name = element[0];
                            currentTankSeries.data.push([element[1], element[2]]);
                        }
                    }, this);
                    if (currentTankSeries.data.length > 0) {
                        seriesOptions.push(currentTankSeries);
                    }
                    renderTimeSeriesChart(seriesOptions);
                });
                $scope.assetData = [];
                PredixAssetService.getChildrentAssetsOfROById('UST', 'GJF074', 2).then(function (data) {
                    console.log(data);
                    $scope.assetData.push({ assetName: 'Tank', assetNo: data.length });
                });
                PredixAssetService.getChildrentAssetsOfROById('Dispenser', 'GJF074', 3).then(function (data) {
                    console.log(data);
                    $scope.assetData.push({ assetName: 'Dispenser', assetNo: data.length });
                });
                PredixAssetService.getChildrentAssetsOfROById('Nozzle', 'GJF074', 4).then(function (data) {
                    console.log(data);
                    $scope.assetData.push({ assetName: 'Nozzle', assetNo: data.length });
                });
            };

            function renderPieChart(pieSeries) {
                var chartOptions = {
                    chart: {
                        animation: false,
                        type: 'pie',
                        spacingBottom: 35,
                        renderTo: "pieChartContainer",
                        style: {
                            color: 'silver'
                        }
                    },
                    title: {
                        text: '',
                        style: {
                            fontSize: '2em',
                            color: 'black'
                        }
                    },
                    exporting: {
                        enabled: false
                    },
                    credits: {
                        enabled: false
                    },
                    rangeSelector: {
                        enabled: false
                    },
                    tooltip: {
                        headerFormat: '<b>{point.x}</b><br/>',
                        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
                    },
                    plotOptions: {
                        pie: {
                            allowPointSelect: true,
                            cursor: 'pointer',
                            dataLabels: {
                                enabled: true,
                                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                                style: {
                                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                                }
                            }
                        }
                    },
                    series: pieSeries
                };
                new Highcharts.Chart(chartOptions);
            };

            function renderTimeSeriesChart(seriesOptions) {

                new Highcharts.Chart({
                    chart: {
                        animation: false,
                        spacingBottom: 35,
                        renderTo: "timeSeriesChartContainer",
                        style: {
                            color: 'silver'
                        }
                    }, credits: {
                        enabled: false
                    },
                    title: {
                        text: 'ATG Data Quality for RO',
                        style: {
                            fontSize: '2em',
                            color: 'black'
                        }
                    },
                    rangeSelector: {
                        selected: 4
                    },
                    xAxis: {
                        type: 'datetime',
                        dateTimeLabelFormats: { // don't display the dummy year
                            month: '%e. %b',
                            year: '%b'
                        },
                        title: {
                            text: 'Date'
                        }
                    },
                    yAxis: {
                        plotLines: [{
                            value: 0,
                            width: 2,
                            color: 'silver'
                        }]
                    },

                    plotOptions: {
                        series: {
                            compare: 'number',
                            showInNavigator: true
                        }
                    },

                    tooltip: {
                        pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.change}%)<br/>',
                        valueDecimals: 2,
                        split: true
                    },

                    series: seriesOptions
                });
            };
            // Init function
            (function () {
                var pieSeries = [{
                    name: 'Brands',
                    colorByPoint: true,
                    data: [{
                        name: 'Petrol',
                        y: 56.33
                    }, {
                        name: 'Diesel',
                        y: 24.03,
                        sliced: true,
                        selected: true
                    }]
                }];
                renderPieChart(pieSeries);

                var seriesOptions = [];
                /* PostgresService.getDataAvailability().then(function (data) {
                    data[0].tags.forEach(function (element) {
                        seriesOptions.push({
                            name: element.name,
                            data: element.results[0].datapoints
                        });
                    }, this);
                    renderTimeSeriesChart(seriesOptions);
                }); */
                (function () {
                    var currentTankSeries = { name: '', data: [] };
                    let currentTankNo = null;
                    let data = [[4, 1482111000000, 4.5000000000000000000], [4, 1482112800000, 4.5000000000000000000], [4, 1482113200000, 7.5000000000000000000], [2, 1482111000000, 7.5000000000000000000], [2, 1482112800000, 5.5000000000000000000], [2, 1482113200000, 7.5000000000000000000]];
                    data.forEach(function (element) {
                        if (currentTankNo) {
                            if (currentTankNo == element[0]) {
                                currentTankSeries.data.push([element[1], element[2]]);
                            } else {
                                seriesOptions.push(currentTankSeries);
                                currentTankSeries = { name: element[0], data: [] };
                                currentTankNo = element[0];
                                currentTankSeries.data.push([element[1], element[2]]);
                            }
                        } else {
                            currentTankNo = element[0];
                            currentTankSeries.name = element[0];
                            currentTankSeries.data.push([element[1], element[2]]);
                        }
                    }, this);
                    if (currentTankSeries.data.length > 0) {
                        seriesOptions.push(currentTankSeries);
                    }
                    renderTimeSeriesChart(seriesOptions);
                }());

                document.addEventListener('px-datetime-submitted', function (event) {
                    console.log(event.detail.dateTime.substring(0, 10));
                    if (event.srcElement.id === 'fromDate') {
                        $scope.fromDate = event.detail.dateTime.substring(0, 10);
                    } else {
                        $scope.toDate = event.detail.dateTime.substring(0, 10);
                    }
                });
                $scope.fromDate = moment().format('YYYY-MM-DD');
                $scope.toDate = moment().format('YYYY-MM-DD');
                //$scope.dataAvailability = [{ "product": "Petrol", "availability": "20" }, { "product": "Diesel", "availability": "30" }];
                $scope.fuelReconcilation = [{
                    "netfuelloss": "25",
                    "losspersale": "20"
                }];
                $scope.wetStockReconcilation = [{
                    "phase": "25",
                    "startdate": "18/05/2017",
                    "billedvolume": "25",
                    "decantationloss": "20",
                    "decantedvolume": "25",
                    "atglevel": "20",
                    "tanksalevolume": "25",
                    "salesloss": "20",
                    "pumpsalevolume": "20"
                }];
                $scope.assetData = [];
                $scope.threshHoldOptions = [{
                    "name": "Petrol",
                    "value": "Petrol"
                }, {
                    "name": "Diesel",
                    "value": "Diesel"
                }];
                $scope.fuelReconcile = 'Petrol';
                $scope.filterData();
            }());

            $scope.$on('$destroy', function iVeBeenDismissed() {
                // say goodbye to your controller here
                // $interval.cancel($scope.refreshPromiseTimer);
            });
        }
    ]);
});

