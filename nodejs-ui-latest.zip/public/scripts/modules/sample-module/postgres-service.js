define(['angular', './sample-module'], function (angular, module) {
    'use strict';

    /**
     * PredixAssetService is a sample service that integrates with Predix Asset Server API
     */
    module.factory('PostgresService', ['$q', '$http', '$rootScope', function ($q, $http, $rootScope) {
        /**
         * Predix Asset server base url
         */
        var baseUrl = '/api/postgres/data_availability';
        var dbHandlerUrl = '/api/db-handler';
        var getDataAvailability = function () {
            var deferred = $q.defer();

            $http.get(baseUrl)
                .then(function (res) {
                    deferred.resolve(res.data);
                },
                function () {
                    deferred.reject('Error fetching reasons');
                });

            return deferred.promise;
        };

        var getDataForROById = function (type, fromDate, toDate) {
            var deferred = $q.defer();
            var url = dbHandlerUrl + '/' + type;
            $http({
                url: url,
                method: "GET",
                params: { FromDt: fromDate, ToDt: toDate, RO_ID: 'MHT004' }
            })
                .then(function (res) {
                    deferred.resolve(res.data);
                },
                function () {
                    deferred.reject('Error fetching reasons');
                });

            return deferred.promise;
        };
        return {
            getDataAvailability: getDataAvailability,
            getDataForROById: getDataForROById
        };
    }]);
});
